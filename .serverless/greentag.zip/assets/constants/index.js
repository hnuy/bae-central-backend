// For development
exports.FILE_TEXT =
  "C:/Users/hnuys/OneDrive/Desktop/bae-center-backend/fileText/"

// For production
// export const SERVER_ADDRESS = 'http://192.168.1.115:3003'
// export const SERVER_ADDRESS = 'http://182.52.108.219:3003'
